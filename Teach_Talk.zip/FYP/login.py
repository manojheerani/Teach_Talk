
from home import Ui_TeachTalk
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_login_Window(object):
    
    def setupUi(self, login_Window):
        self.login_Window= login_Window
        self.login_Window.setObjectName("login_Window")
        self.login_Window.resize(592, 330)
        self.login_Window.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.login_Window.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.login_Window.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setBold(True)
        font.setWeight(75)
        self.login_Window.setFont(font)
        self.centralwidget = QtWidgets.QWidget(self.login_Window)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(10, 10, 571, 301))
        self.frame.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));\n"
"border-radius:5px;")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(170, 20, 191, 61))
        font = QtGui.QFont()
        font.setPointSize(32)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("background-color:none;\n"
"color:rgba(255,255,255,255);")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(40, 110, 71, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.frame)
        self.label_3.setGeometry(QtCore.QRect(40, 170, 71, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_3.setObjectName("label_3")
        self.lineEdit = QtWidgets.QLineEdit(self.frame)
        self.lineEdit.setGeometry(QtCore.QRect(150, 120, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lineEdit.setFont(font)
        self.lineEdit.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :1px solid  rgba(255, 255, 255, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;\n"
"\n"
"border-radius:none;")
        self.lineEdit.setObjectName("lineEdit")
        self.PushButton = QtWidgets.QPushButton(self.frame , clicked=lambda:self.MyFun())
        self.PushButton.setGeometry(QtCore.QRect(280, 230, 151, 51))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton.setFont(font)
        self.PushButton.setStyleSheet("QPushButton#PushButton{\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(255, 133, 223, 255), stop:1 rgba(182, 130, 255, 255));\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#PushButton:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#PushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.PushButton.setObjectName("PushButton")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.frame)
        self.lineEdit_2.setGeometry(QtCore.QRect(150, 170, 241, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lineEdit_2.setFont(font)
        self.lineEdit_2.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :1px solid  rgba(255, 255, 255, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;\n"
"\n"
"border-radius:none;")
        self.lineEdit_2.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.back_btn = QtWidgets.QPushButton(self.frame , clicked=lambda:self.close_Window())
        self.back_btn.setGeometry(QtCore.QRect(540, 10, 21, 23))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.back_btn.setFont(font)
        self.back_btn.setStyleSheet("QPushButton#back_btn{\n"
"background:none;\n"
"    \n"
"}\n"
"\n"
"\n"
"QPushButton#back_btn:hover{\n"
"background-color:red;\n"
"color:white;\n"
"border:1px solid white;\n"
"border-radius:0px;\n"
"}\n"
"\n"
"QPushButton#PushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.back_btn.setObjectName("back_btn")
        login_Window.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(login_Window)
        self.statusbar.setObjectName("statusbar")
        login_Window.setStatusBar(self.statusbar)

        self.retranslateUi(login_Window)
        QtCore.QMetaObject.connectSlotsByName(login_Window)
    def close_Window(self):
        self.login_Window.close()
    def openNew_window(self):
        self.login_Window.close()
        self.window = QtWidgets.QMainWindow()
        ui = Ui_TeachTalk()
        ui.setupUi(self.window)
        self.window.show()
        

    def retranslateUi(self, login_Window):
        _translate = QtCore.QCoreApplication.translate
        login_Window.setWindowTitle(_translate("login_Window", "MainWindow"))
        self.label.setText(_translate("login_Window", "Login"))
        self.label_2.setText(_translate("login_Window", "Username"))
        self.label_3.setText(_translate("login_Window", "Password"))
        self.lineEdit.setPlaceholderText(_translate("login_Window", "Username"))
        self.PushButton.setText(_translate("login_Window", "Login"))
        self.lineEdit_2.setPlaceholderText(_translate("login_Window", "Password"))
        self.back_btn.setText(_translate("login_Window", "x"))
    def MyFun(self):
        if self.lineEdit.text() == 'root' and self.lineEdit_2.text() == '1234':
                self.openNew_window()
        else:
                self.lineEdit.setText('')
                self.lineEdit_2.setText('')
    


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    login_Window1 = QtWidgets.QMainWindow()
    ui = Ui_login_Window()
    ui.setupUi(login_Window1)
    login_Window1.show()
    sys.exit(app.exec_())
