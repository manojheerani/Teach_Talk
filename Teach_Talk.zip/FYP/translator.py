# import imp
import speech_recognition as sr

from google_trans_new import google_translator
from gtts import gTTS
from playsound import playsound


# r = sr.Recognizer()
 
# print('Speak Now ! ')
# with sr.Microphone() as sourse:

#     r.adjust_for_ambient_noise(sourse)
#     audio = r.listen(sourse)

#     try:

#         speech_text = r.recognize_google(audio)

#         print(speech_text)
#         translated_text = google_translator().translate(speech_text,lang_tgt='fr')
#         print(translated_text)

#     except sr.UnknownValueError as e:
#         print(e)
# translated_text = google_translator().translate("hello world",lang_tgt='fr')
# print(translated_text)
    
    # print(translated_text)


from googletrans import Translator,LANGCODES
lang = list(LANGCODES.values())
translator = Translator()
# print(translator.translate('안녕하세요.').text)

# print(lang)
# translator.translate('안녕하세요.', dest='en')
# translations = translator.translate(['The quick brown fox', 'jumps over', 'the lazy dog'], dest='ko')
# # print(translations)
# for translation in translations:
#     print(translation.origin, ' -> ', translation.text)

# translator = Translator()
translated = translator.translate(text= "hello world",  src = 'en',dest = 'sd')
print(translated.text)
