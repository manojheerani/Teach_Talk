import webbrowser
import os
from itertools import count
from Quiz1 import Quiz
import icons
import speech_recognition as sr
import pyttsx3
from PyQt5 import QtCore, QtGui, QtWidgets
from googletrans import Translator
# from mygif import MainWindow
from signup import Ui_MainWindow
# from mygif import Loading

import translation_s


class Ui_TeachTalk(object):
    my_text = ''
    count = 0

    def setupUi(self, TeachTalk):
        TeachTalk.setObjectName("TeachTalk")
        TeachTalk.resize(1350, 671)
        TeachTalk.setStyleSheet("")
        self.centralwidget = QtWidgets.QWidget(TeachTalk)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(0, 0, 171, 680))
        self.frame.setStyleSheet(
            "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 153, 255), stop:1 rgba(124, 0, 0, 255));")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.profile = QtWidgets.QPushButton(
            self.frame, clicked=lambda: self.profile_clk())
        self.profile.setGeometry(QtCore.QRect(10, 100, 146, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)

        self.profile.setFont(font)
        self.profile.setStyleSheet("QPushButton#profile{\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                   "color:rgba(255,255,255,1);\n"
                                   "border-radius:5px;\n"
                                   "}\n"
                                   "\n"
                                   "\n"
                                   "QPushButton#profile:hover{\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                   "color:rgba(255,255,255,210);\n"
                                   "border-radius:5px;\n"
                                   "}\n"
                                   "\n"
                                   "QPushButton#profile:pressed{\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                   "color:rgba(255,255,255,210);\n"
                                   "border-radius:5px;\n"
                                   "}\n"
                                   "\n"
                                   "")
        self.profile.setObjectName("profile")
        self.translator = QtWidgets.QPushButton(
            self.frame, clicked=lambda: self._translate())
        self.translator.setGeometry(QtCore.QRect(10, 190, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.translator.setFont(font)
        self.translator.setStyleSheet("QPushButton#translator{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                      "color:rgba(255,255,255,1);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "\n"
                                      "QPushButton#translator:hover{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "QPushButton#translator:pressed{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "")
        self.translator.setObjectName("translator")
        self.books = QtWidgets.QPushButton(
            self.frame, clicked=lambda: self.books_read())
        self.books.setGeometry(QtCore.QRect(10, 280, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.books.setFont(font)
        self.books.setStyleSheet("QPushButton#books{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                 "color:rgba(255,255,255,1);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "QPushButton#books:hover{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                 "color:rgba(255,255,255,210);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "QPushButton#books:pressed{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                 "color:rgba(255,255,255,210);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "")
        self.books.setObjectName("books")
        self.social = QtWidgets.QPushButton(self.frame)
        self.social.setGeometry(QtCore.QRect(10, 370, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.social.setFont(font)
        self.social.setStyleSheet("QPushButton#social{\n"
                                  "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                  "color:rgba(255,255,255,1);\n"
                                  "border-radius:5px;\n"
                                  "}\n"
                                  "\n"
                                  "\n"
                                  "QPushButton#social:hover{\n"
                                  "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                  "color:rgba(255,255,255,210);\n"
                                  "border-radius:5px;\n"
                                  "}\n"
                                  "\n"
                                  "QPushButton#social:pressed{\n"
                                  "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                  "color:rgba(255,255,255,210);\n"
                                  "border-radius:5px;\n"
                                  "}\n"
                                  "\n"
                                  "")
        self.social.setObjectName("social")
        self.quiz = QtWidgets.QPushButton(self.frame,clicked=lambda:self.quizOpen())
        self.quiz.setGeometry(QtCore.QRect(10, 460, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.quiz.setFont(font)
        self.quiz.setStyleSheet("QPushButton#quiz{\n"
                                "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                "color:rgba(255,255,255,1);\n"
                                "border-radius:5px;\n"
                                "}\n"
                                "\n"
                                "\n"
                                "QPushButton#quiz:hover{\n"
                                "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                "color:rgba(255,255,255,210);\n"
                                "border-radius:5px;\n"
                                "}\n"
                                "\n"
                                "QPushButton#quiz:pressed{\n"
                                "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                "color:rgba(255,255,255,210);\n"
                                "border-radius:5px;\n"
                                "}\n"
                                "\n"
                                "")
        self.quiz.setObjectName("quiz")
        self.games = QtWidgets.QPushButton(
            self.frame, clicked=lambda: self.openGames())
        self.games.setGeometry(QtCore.QRect(10, 550, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.games.setFont(font)
        self.games.setStyleSheet("QPushButton#games{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                 "color:rgba(255,255,255,1);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "QPushButton#games:hover{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                 "color:rgba(255,255,255,210);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "QPushButton#games:pressed{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                 "color:rgba(255,255,255,210);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "")
        self.games.setObjectName("games")
        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setGeometry(QtCore.QRect(169, -1, 1180, 680))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.frame_2.setFont(font)
        self.frame_2.setStyleSheet(
            "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 153, 255), stop:1 rgba(124, 0, 0, 255));")
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.lineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.lineEdit.setGeometry(QtCore.QRect(120, 40, 871, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lineEdit.setFont(font)
        self.lineEdit.setStyleSheet("background-color:rgba(0,0,0,0);\n"
                                    "border:none;\n"
                                    "\n"
                                    "border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
                                    "color: rgba(255,255,255,230);\n"
                                    "padding-bottom:7px;")
        self.lineEdit.setObjectName("lineEdit")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.frame_2)
        self.plainTextEdit.setGeometry(QtCore.QRect(10, 100, 1141, 511))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.plainTextEdit.setFont(font)
        self.plainTextEdit.setMouseTracking(True)
        self.plainTextEdit.setStyleSheet(
            "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(227, 160, 247, 240), stop:1 rgba(220, 217, 221, 255));")
        self.plainTextEdit.setReadOnly(True)
        self.plainTextEdit.setOverwriteMode(False)
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.search = QtWidgets.QPushButton(self.frame_2)
        self.search.setGeometry(QtCore.QRect(1000, 40, 21, 31))
        self.search.setStyleSheet("QPushButton#search{\n"
                                  "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                  "color:rgba(255,255,255,1);\n"
                                  "border-radius:5px;\n"
                                  "}\n"
                                  "\n"
                                  "\n"
                                  "QPushButton#search:hover{\n"
                                  "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                  "color:rgba(255,255,255,210);\n"
                                  "border-radius:5px;\n"
                                  "}\n"
                                  "\n"
                                  "QPushButton#search:pressed{\n"
                                  "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                  "color:rgba(255,255,255,210);\n"
                                  "border-radius:5px;\n"
                                  "}")
        self.search.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(
            ":/newPrefix/icons8-search-60.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.search.setIcon(icon)
        self.search.setIconSize(QtCore.QSize(18, 18))
        self.search.setObjectName("search")
        self.voice_srch = QtWidgets.QPushButton(
            self.frame_2, clicked=lambda: self.Voice_Search())
        self.voice_srch.setGeometry(QtCore.QRect(1030, 40, 21, 31))
        self.voice_srch.setStyleSheet("QPushButton#voice_srch{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                      "color:rgba(255,255,255,1);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "\n"
                                      "QPushButton#voice_srch:hover{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "QPushButton#voice_srch:pressed{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}")
        self.voice_srch.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/newPrefix/google-voice.png"),
                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.voice_srch.setIcon(icon1)
        self.voice_srch.setIconSize(QtCore.QSize(20, 20))
        self.voice_srch.setObjectName("voice_srch")
        self.comboBox = QtWidgets.QComboBox(self.frame_2)
        self.comboBox.setGeometry(QtCore.QRect(1080, 50, 81, 22))
        self.comboBox.setStyleSheet("QComboBox#comboBox{\n"
                                    "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                    "color:rgba(255,255,255,1);\n"
                                    "border-radius:5px;\n"
                                    "}\n"
                                    "\n"
                                    "\n"
                                    "QComboBox#comboBox:hover{\n"
                                    "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                    "color:rgba(255,255,255,210);\n"
                                    "border-radius:5px;\n"
                                    "}\n"
                                    "\n"
                                    "QComboBox#comboBox:pressed{\n"
                                    "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                    "color:rgba(255,255,255,210);\n"
                                    "border-radius:5px;\n"
                                    "}")
        self.comboBox.setObjectName("comboBox")
        self.lang_list = ['', 'English', 'Urdu', 'Sindhi']
        self.comboBox.addItems(self.lang_list)
        self.label = QtWidgets.QLabel(self.frame_2)
        self.label.setGeometry(QtCore.QRect(1080, 30, 81, 16))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("QLabel#label{\n"
                                 "    \n"
                                 "background:none;\n"
                                 "color:white;\n"
                                 "    border-radius:7px;\n"
                                 "}")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.start = QtWidgets.QPushButton(self.frame_2)
        self.start.setGeometry(QtCore.QRect(670, 620, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.start.setFont(font)
        self.start.setStyleSheet("QPushButton#start{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                 "color:rgba(255,255,255,1);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "QPushButton#start:hover{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                 "color:rgba(255,255,255,210);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "QPushButton#start:pressed{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                 "color:rgba(255,255,255,210);\n"
                                 "border-radius:5px;\n"
                                 "}\n"
                                 "\n"
                                 "")

        self.start.setObjectName("start")
        self.stop = QtWidgets.QPushButton(self.frame_2)
        self.stop.setGeometry(QtCore.QRect(360, 620, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.stop.setFont(font)
        self.stop.setStyleSheet("QPushButton#stop{\n"
                                "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                "color:rgba(255,255,255,1);\n"
                                "border-radius:5px;\n"
                                "}\n"
                                "\n"
                                "\n"
                                "QPushButton#stop:hover{\n"
                                "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                "color:rgba(255,255,255,210);\n"
                                "border-radius:5px;\n"
                                "}\n"
                                "\n"
                                "QPushButton#stop:pressed{\n"
                                "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                "color:rgba(255,255,255,210);\n"
                                "border-radius:5px;\n"
                                "}\n"
                                "\n"
                                "")
        self.stop.setObjectName("stop")
        TeachTalk.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(TeachTalk)
        self.statusbar.setObjectName("statusbar")
        TeachTalk.setStatusBar(self.statusbar)

        self.retranslateUi(TeachTalk)
        QtCore.QMetaObject.connectSlotsByName(TeachTalk)
        
        
        # myobj.Timerr()

    def retranslateUi(self, TeachTalk):
        _translate = QtCore.QCoreApplication.translate
        TeachTalk.setWindowTitle(_translate("TeachTalk", "TeachTalk"))
        self.profile.setText(_translate("TeachTalk", "Profile"))
        self.translator.setText(_translate("TeachTalk", "Translator"))
        self.books.setText(_translate("TeachTalk", "Books"))
        self.social.setText(_translate("TeachTalk", "Social"))
        self.quiz.setText(_translate("TeachTalk", "Quizes"))
        self.games.setText(_translate("TeachTalk", "Games"))
        self.lineEdit.setPlaceholderText(
            _translate("TeachTalk", "Search here"))
        self.label.setText(_translate("TeachTalk", "LANGUAGE"))
        self.start.setText(_translate("TeachTalk", "Start"))
        self.stop.setText(_translate("TeachTalk", "Stop"))

    def Voice_Search(self):
        r = sr.Recognizer()
        mic = sr.Microphone()

        with mic as sourse:
            self.lineEdit.setText('Listening....')
            r.adjust_for_ambient_noise(sourse)
            audio1 = r.listen(sourse)
            a = r.recognize_google(audio1)

            self.lineEdit.setText(a)
            
            
            
            self.search_result()
            
    def search_result(self):
        self.text = """ 1. An object at rest remains at rest, and an object in motion remains in motion at constant speed and in a straight line unless acted on by an unbalanced force.
 2.The acceleration of an object depends on the mass of the object and the amount of force applied.
 3. Whenever one object exerts a force on another object, the second object exerts an equal and opposite on the first.
 Newton’s First Law: Inertia
An object at rest remains at rest, and an object in motion remains in motion at constant speed and in a straight line unless acted on by an unbalanced force.
Newton’s first law states that every object will remain at rest or in uniform motion in a straight line unless compelled to change its state by the action of an external force. This tendency to resist changes in a state of motion is inertia. If all the external forces cancel each other out, then there is no net force acting on the object.  If there is no net force acting on the object, then the object will maintain a constant velocity.

Examples of inertia involving aerodynamics:
The motion of an airplane when a pilot changes the throttle setting of an engine.
The motion of a ball falling down through the atmosphere.
A model rocket being launched up into the atmosphere.
The motion of a kite when the wind changes.
Newton’s Second Law: Force
The acceleration of an object depends on the mass of the object and the amount of force applied.
His second law defines a force to be equal to change in momentum (mass times velocity) per change in time. Momentum is defined to be the mass m of an object times its velocity V.
Let us assume that we have an airplane at a point “0” defined by its location X0 and time t0. The airplane has a mass m0 and travels at velocity V0. An external force F to the airplane shown above moves it to point “1”. The airplane’s new location is X1 and time t1.

The mass and velocity of the airplane change during the flight to values m1 and V1. Newton’s second law can help us determine the new values of V1 and m1, if we know how big the force F is. Let us just take the difference between the conditions at point “1” and the conditions at point “0”.

F = (m1 * V1 – m0 * V0) / (t1 – t0)
Newton’s second law talks about changes in momentum (m * V). So at this point, we can’t separate out how much the mass changed and how much the velocity changed. We only know how much product (m * V) changed.

Let us assume that the mass stays at a constant value equal to m. This assumption is rather good for an airplane because the only change in mass would be for the fuel burned between point “1” and point “0”. The weight of the fuel is probably small relative to the weight of the rest of the airplane, especially if we only look at small changes in time. If we were discussing the flight of a baseball,  then certainly the mass remains a constant. But if we were discussing the flight of a bottle rocket, then the mass does not remain a constant and we can only look at changes in momentum. For a constant mass m, Newton’s second law looks like:

F = m * (V1 – V0) / (t1 – t0)
The change in velocity divided by the change in time is the definition of the acceleration a. The second law then reduces to the more familiar product of a mass and an acceleration:

F = m * a
Remember that this relation is only good for objects that have a constant mass. This equation tells us that an object subjected to an external force will accelerate and that the amount of the acceleration is proportional to the size of the force. The amount of acceleration is also inversely proportional to the mass of the object; for equal forces, a heavier object will experience less acceleration than a lighter object. Considering the momentum equation, a force causes a change in velocity; and likewise, a change in velocity generates a force. The equation works both ways.

The velocity, force, acceleration, and momentum have both a magnitude and a direction associated with them. Scientists and mathematicians call this a vector quantity. The equations shown here are actually vector equations and can be applied in each of the component directions. We have only looked at one direction, and, in general, an object moves in all three directions (up-down, left-right, forward-back).

Example of force involving aerodynamics:
An aircraft’s motion resulting from aerodynamic forces, aircraft weight, and thrust.
Newton’s Third Law: Action & Reaction
Whenever one object exerts a force on a second object, the second object exerts an equal and opposite force on the first.
His third law states that for every action (force) in nature there is an equal and opposite reaction. If object A exerts a force on object B, object B also exerts an equal and opposite force on object A. In other words, forces result from interactions.

Examples of action and reaction involving aerodynamics:
The motion of lift from an airfoil, the air is deflected downward by the airfoil’s action, and in reaction, the wing is pushed upward.
The motion of a spinning ball, the air is deflected to one side, and the ball reacts by moving in the opposite
The motion of a jet engine produces thrust and hot exhaust gases flow out the back of the engine, and a thrusting force is produced in the opposite direction."""
        self.plainTextEdit.setPlainText(self.text)

    def openWindow(self):
        self.window = QtWidgets.QMainWindow()
        global count
        if count == 2:
            #     self._translate()
            ui = Ui_MainWindow()
            ui.setupUi(self.window)
            self.window.show()
            count = 0
        elif count == 1:
            #     self._translate()
            ui = Ui_MainWindow()
            ui.setupUi(self.window)
            self.window.show()
            count = 0
        elif count == 3:
            ui = Quiz()
            ui.setupUi(self.window)
            self.window.show()
    def _translate(self):

        global count
        self.my_text = self.plainTextEdit.textCursor().selectedText()
        print(self.my_text)
        count = 2

        #     self.sendData()
        #     print(count)
        #     print(my_text)

        self.openWindow()

    def profile_clk(self):
        global count
        count = 1
        self.openWindow()

    def send(self):
        return (self.plainTextEdit.textCursor().selectedText())

    def openGames(self):
        # self.url ='https://poki.com/'
        self.url = 'https://www.crazygames.com/game/drift-hunters'
        self.chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
        webbrowser.get(self.chrome_path).open(self.url)

    def books_read(self):
        # self.url = 'https://drive.google.com/file/d/1gHBj6E7rWH9cBkmSz8NSd6l-ElsQx8Cj/view'
        # self.chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
        # webbrowser.get(self.chrome_path).open(self.url)
        path = 'Physics9.pdf'

        os.system(path)
    def quizOpen(self):
        global count
        count = 3
        self.openWindow()
             


# ============================================================================================
        #    Translation Class
# ==============================================================================================


class Ui_MainWindow(Ui_TeachTalk, object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(673, 398)

        MainWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        MainWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        MainWindow.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(10, 10, 651, 351))
        self.frame.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));\n"
                                 "border-radius:7px;")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.frame)
        self.plainTextEdit.setGeometry(QtCore.QRect(10, 50, 631, 121))
        self.plainTextEdit.setStyleSheet("QPlainTextEdit#plainTextEdit{\n"
                                         "background:white;\n"
                                         "color:black;\n"
                                         "border-radius:3px\n"
                                         "}")
        self.plainTextEdit.setObjectName("plainTextEdit")
        # self.plainTextEdit.setPlainText(home.Ui_TeachTalk.my_text)
        self.plainTextEdit_2 = QtWidgets.QPlainTextEdit(self.frame)
        self.plainTextEdit_2.setGeometry(QtCore.QRect(10, 180, 631, 131))
        self.plainTextEdit_2.setStyleSheet("QPlainTextEdit#plainTextEdit_2{\n"
                                           "background:white;\n"
                                           "color:black;\n"
                                           "border-radius:3px\n"
                                           "}")
        self.plainTextEdit_2.setReadOnly(True)
        self.plainTextEdit_2.setObjectName("plainTextEdit_2")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(110, 10, 91, 16))
        self.label.setStyleSheet("QLabel#label{\n"
                                 "background:none;\n"
                                 "color:white;\n"
                                 "}")
        self.label.setObjectName("label")
        self.comboBox = QtWidgets.QComboBox(self.frame)
        self.comboBox.setGeometry(QtCore.QRect(458, 10, 181, 22))
        self.comboBox.setObjectName("comboBox")
        self.lang_list = ['', 'Urdu', 'Sindhi']
        self.comboBox.addItems(self.lang_list)
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(350, 10, 91, 16))
        self.label_2.setStyleSheet("QLabel#label_2{\n"
                                   "background:none;\n"
                                   "color:white;\n"
                                   "}")
        self.label_2.setObjectName("label_2")
        self.pushButton = QtWidgets.QPushButton(
            self.frame, clicked=lambda: self._translator())
        self.pushButton.setGeometry(QtCore.QRect(234, 320, 161, 23))
        self.pushButton.setStyleSheet("QPushButton#pushButton{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                      "color:rgba(255,255,255,1);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "\n"
                                      "QPushButton#pushButton:hover{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "QPushButton#pushButton:pressed{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "")
        self.pushButton.setObjectName("pushButton")
        self.back_btn = QtWidgets.QPushButton(
            self.frame, clicked=lambda: MainWindow.close())
        self.back_btn.setGeometry(QtCore.QRect(20, 10, 31, 23))
        self.back_btn.setStyleSheet("QPushButton#back_btn{\n"
                                    "background:none;\n"
                                    "}")
        self.back_btn.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/newPrefix/back.png"),
                       QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.back_btn.setIcon(icon)
        self.back_btn.setObjectName("back_btn")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # self.obj = Ui_TeachTalk()

        print("this is global   : ", self.send())
        # self.plainTextEdit.setPlainText(self.send())

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Original Text"))
        self.label_2.setText(_translate("MainWindow", "Select Language"))
        self.pushButton.setText(_translate("MainWindow", "Translate"))

    def _translator(self):
        translator = Translator()

        try:

            org_text = self.plainTextEdit.toPlainText()

            self.currentLang = ''
            if (self.comboBox.currentText() == 'Sindhi'):
                self.currentLang = 'sd'
            elif (self.comboBox.currentText() == 'Urdu'):
                self.currentLang = 'ur'
            translated_text = translator.translate(
                text=org_text,  src='en', dest=self.currentLang)

            self.plainTextEdit_2.setPlainText(translated_text.text)
        except Exception as e:
            print(e)







# ====================================================================================
                        # LOADING OR WAITING SCREEN 
# ======================================================================================



# from itertools import count
# from shutil import move
# from PyQt5 import QtCore, QtGui, QtWidgets

# from PyQt5.QtGui import QMovie
# from PyQt5.QtCore import QTimer
# count = 0
# class Loading(object):
#     def setupUi(self, MainWindow):
#         MainWindow.setObjectName("MainWindow")
#         MainWindow.resize(178, 157)
#         MainWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
#         MainWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)
#         MainWindow.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
#         MainWindow.setStyleSheet("background:none;")
#         self.centralwidget = QtWidgets.QWidget(MainWindow)
#         self.centralwidget.setObjectName("centralwidget")
#         self.movie = QMovie('MnyxU.gif')
#         self.label = QtWidgets.QLabel(self.centralwidget)
#         self.label.setGeometry(QtCore.QRect(10, 10, 161, 111))
#         self.label.setStyleSheet("background:none;")
#         self.label.setText("")
#         self.label.setScaledContents(True)
#         self.label.setObjectName("label")
#         self.label.setMovie(self.movie)
#         MainWindow.setCentralWidget(self.centralwidget)
#         self.statusbar = QtWidgets.QStatusBar(MainWindow)
#         self.statusbar.setObjectName("statusbar")
#         MainWindow.setStatusBar(self.statusbar)
        
#         self.timer = QTimer()
#         self.timer.timeout.connect(self.Timerr)
#         self.timer.start(35)

#         self.retranslateUi(MainWindow)
#         QtCore.QMetaObject.connectSlotsByName(MainWindow)
    
        
        
#     def retranslateUi(self, MainWindow):
#         _translate = QtCore.QCoreApplication.translate
#         MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
#     def start_anim(self):
#         self.movie.start()
#     def stop_anim(self):
#         self.movie.stop()
#         self.MainWindow.close()
#         # self.MainWindow.close()
        
#     def Timerr(self):
#         self.start_anim()
#         global count
#         if count>50:
#             self.timer.stop()
#             self.stop_anim()
#         count +=1;


# if __name__ == "__main__":
#     import sys
#     app = QtWidgets.QApplication(sys.argv)
#     MainWindow = QtWidgets.QMainWindow()
#     ui = Loading()
#     ui.setupUi(MainWindow)
#     MainWindow.show()
#     sys.exit(app.exec_())



# ==================================================================================================
            # Main Method
# ====================================================================================================
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    TeachTalk = QtWidgets.QMainWindow()
    ui = Ui_TeachTalk()
    ui.setupUi(TeachTalk)
    TeachTalk.show()
    sys.exit(app.exec_())
