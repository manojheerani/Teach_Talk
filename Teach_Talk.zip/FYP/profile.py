
import sqlite3
import icons
import tkinter as tk
from tkinter import filedialog
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(512, 585)
        Form.setStyleSheet("\n"
"background-color: qlineargradient(spread:pad, x1:0.295455, y1:0.159, x2:1, y2:1, stop:0.361295 rgba(18, 0, 37, 255), stop:0.854314 rgba(232, 36, 84, 255), stop:0.982955 rgba(255, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius:7px;\n"
"")
        self.frame = QtWidgets.QFrame(Form)
        self.frame.setGeometry(QtCore.QRect(0, -10, 511, 171))
        self.frame.setStyleSheet("QFrame#frame{\n"
"background:white;\n"

"border-bottom:1px sloid ;\n"
"border-radius:10px;\n"
"}")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(200, 60, 101, 101))
        self.label.setStyleSheet("QLabel#label{\n"
"background:black;\n"
"border-radius:45px;\n"
"}")
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap(":/newPrefix/Icon/icons8-test-account-96.png"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.frame_2 = QtWidgets.QFrame(Form)
        self.frame_2.setGeometry(QtCore.QRect(0, 160, 511, 431))
        self.frame_2.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));")
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.pushButton = QtWidgets.QPushButton(self.frame_2,clicked=lambda:self.setImg())
        self.pushButton.setGeometry(QtCore.QRect(210, 50, 75, 23))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("QPushButton#pushButton{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#pushButton:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.pushButton.setObjectName("pushButton")
        self.frame_3 = QtWidgets.QFrame(self.frame_2)
        self.frame_3.setGeometry(QtCore.QRect(0, 80, 511, 221))
        self.frame_3.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_3.setObjectName("frame_3")
        self.label_2 = QtWidgets.QLabel(self.frame_3)
        self.label_2.setGeometry(QtCore.QRect(10, 10, 81, 16))
        self.label_2.setStyleSheet("QLabel#label_2{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_2.setObjectName("label_2")
        self.lineEdit = QtWidgets.QLineEdit(self.frame_3)
        self.lineEdit.setGeometry(QtCore.QRect(20, 50, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit.setFont(font)
        self.lineEdit.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.lineEdit.setReadOnly(True)
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.frame_3)
        self.lineEdit_3.setGeometry(QtCore.QRect(270, 150, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_3.setFont(font)
        self.lineEdit_3.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        # self.getData()
        self.lineEdit_3.setReadOnly(True)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.frame_3)
        self.lineEdit_4.setGeometry(QtCore.QRect(270, 50, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_4.setFont(font)
        self.lineEdit_4.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"")
        self.lineEdit_4.setReadOnly(True)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.edit = QtWidgets.QPushButton(self.frame_3)
        self.edit.setGeometry(QtCore.QRect(430, 0, 75, 23))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.edit.setFont(font)
        self.edit.setStyleSheet("QPushButton#edit{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#edit:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#edit:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.edit.setObjectName("edit")
        
        self.standard = ['1','2','3','4','5','6','7','8','9','10','11','12']
        
        self.comboBox = QtWidgets.QComboBox(self.frame_3)
        self.comboBox.setGeometry(QtCore.QRect(100, 110, 121, 22))
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItems(self.standard)
        self.label_3 = QtWidgets.QLabel(self.frame_3)
        self.label_3.setGeometry(QtCore.QRect(20, 110, 51, 16))
        self.label_3.setStyleSheet("QLabel#label_3{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_3.setObjectName("label_3")
        self.lineEdit_5 = QtWidgets.QLineEdit(self.frame_3)
        self.lineEdit_5.setGeometry(QtCore.QRect(20, 150, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_5.setFont(font)
        self.lineEdit_5.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.lineEdit_5.setReadOnly(True)
        self.lineEdit_5.setObjectName("lineEdit_5")
        self.Name = QtWidgets.QLabel(self.frame_2)
        self.Name.setGeometry(QtCore.QRect(100, 10, 301, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.Name.setFont(font)
        self.Name.setStyleSheet("QLabel#Name{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.Name.setAlignment(QtCore.Qt.AlignCenter)
        self.Name.setObjectName("Name")
        self.frame_4 = QtWidgets.QFrame(self.frame_2)
        self.frame_4.setGeometry(QtCore.QRect(0, 300, 511, 121))
        self.frame_4.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_4.setObjectName("frame_4")
        self.label_4 = QtWidgets.QLabel(self.frame_4)
        self.label_4.setGeometry(QtCore.QRect(0, 0, 81, 16))
        self.label_4.setStyleSheet("QLabel#label_4{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_4.setObjectName("label_4")
        self.username = QtWidgets.QLineEdit(self.frame_4)
        self.username.setGeometry(QtCore.QRect(70, 30, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.username.setFont(font)
        self.username.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.username.setReadOnly(True)
        self.username.setObjectName("username")
        self.password = QtWidgets.QLineEdit(self.frame_4)
        self.password.setGeometry(QtCore.QRect(70, 90, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.password.setFont(font)
        self.password.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password.setReadOnly(True)
        self.password.setObjectName("password")
        self.username_2 = QtWidgets.QLineEdit(self.frame_4)
        self.username_2.setGeometry(QtCore.QRect(330, 90, 141, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.username_2.setFont(font)
        self.username_2.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.username_2.setReadOnly(True)
        self.username_2.setObjectName("username_2")
        self.label_5 = QtWidgets.QLabel(self.frame_4)
        self.label_5.setGeometry(QtCore.QRect(320, 40, 151, 16))
        self.label_5.setStyleSheet("QLabel#label_5{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_5.setAlignment(QtCore.Qt.AlignCenter)
        self.label_5.setObjectName("label_5")
        self.save = QtWidgets.QPushButton(self.frame_4)
        self.save.setGeometry(QtCore.QRect(424, 10, 81, 23))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.save.setFont(font)
        self.save.setStyleSheet("QPushButton#save{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#save:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#save:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.save.setObjectName("save")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)
        self.getData()

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton.setText(_translate("Form", "Change"))
        self.label_2.setText(_translate("Form", "Personal Details"))
        self.edit.setText(_translate("Form", "Edit"))
        self.label_3.setText(_translate("Form", "Standard"))
        self.Name.setText(_translate("Form", "Personal Details"))
        self.label_4.setText(_translate("Form", "Personal Details"))
        self.username.setPlaceholderText(_translate("Form", "username"))
        self.password.setPlaceholderText(_translate("Form", "Password"))
        self.username_2.setPlaceholderText(_translate("Form", "username"))
        self.label_5.setText(_translate("Form", "Password hint"))
        self.save.setText(_translate("Form", "Save"))

    def setImg(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.file_path = filedialog.askopenfilename()
        self.label.setPixmap(QtGui.QPixmap(self.file_path))   
        
    def getData(self):
        try:
                self.sql = sqlite3.connect('database.db')
                self.cursor = self.sql.cursor()
                print('Connected...')
                query = 'select * from signup'
                myData = self.cursor.fetchall()
                for row in myData:
                        self.lineEdit.setText(row[1])
                        self.username.setText(row[2])
                        print(row[1])
                        self.lineEdit_4.setText(row[3])
                        self.lineEdit_3.setText(row[1])
                        # self.us = row[2]
                        # self.passs = row[3]
                        # self.hint = row[4]
                        # self.pic = row[6]
                # self.lineEdit.setText(self.nam)
                # self.username.setText(self.us)
                # self.lineEdit_4.setText(self.passs)
                        self.label.setPixmap(QtGui.QPixmap(row[6]))
                
                
                
        except Exception as e:
                print(e)

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())
