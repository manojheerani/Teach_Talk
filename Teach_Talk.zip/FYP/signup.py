
import icons
import tkinter as tk
from tkinter import filedialog

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(533, 577)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(0, 0, 531, 571))
        self.frame.setStyleSheet("background-color: #4da6ff;")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(180, 10, 291, 61))
        font = QtGui.QFont()
        font.setPointSize(30)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("QLabel#label{\n"
"color: white;\n"
"}\n"
"QLabel#labe:hoverl{\n"
"color: red;\n"
"}")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.img_lbl = QtWidgets.QLabel(self.frame)
        self.img_lbl.setGeometry(QtCore.QRect(20, 40, 101, 111))
        self.img_lbl.setStyleSheet("background-color:grey;")
        self.img_lbl.setText("")
        self.img_lbl.setScaledContents(True)
        self.img_lbl.setObjectName("img_lbl")
        self.browse_bt = QtWidgets.QPushButton(self.frame,clicked=lambda:self.setImg())
        self.browse_bt.setGeometry(QtCore.QRect(20, 160, 101, 23))
        self.browse_bt.setStyleSheet("QPushButton#browse_bt{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #005c99, stop:1 #008ae6);\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#browse_bt:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #1aa3ff, stop:1#1a1aff);\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#browse_bt:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.browse_bt.setObjectName("browse_bt")
        self.label_6 = QtWidgets.QLabel(self.frame)
        self.label_6.setGeometry(QtCore.QRect(140, 140, 81, 16))
        self.label_6.setStyleSheet("QLabel#label_6{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.frame)
        self.label_7.setGeometry(QtCore.QRect(50, 190, 41, 21))
        self.label_7.setStyleSheet("QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_7.setObjectName("label_7")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.frame)
        self.lineEdit_2.setGeometry(QtCore.QRect(110, 190, 291, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_2.setFont(font)
        self.lineEdit_2.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_2.setReadOnly(False)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.label_8 = QtWidgets.QLabel(self.frame)
        self.label_8.setGeometry(QtCore.QRect(40, 240, 51, 21))
        self.label_8.setStyleSheet("QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_8.setObjectName("label_8")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.frame)
        self.lineEdit_3.setGeometry(QtCore.QRect(110, 240, 291, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_3.setFont(font)
        self.lineEdit_3.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_3.setReadOnly(False)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.label_9 = QtWidgets.QLabel(self.frame)
        self.label_9.setGeometry(QtCore.QRect(40, 300, 51, 21))
        self.label_9.setStyleSheet("QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_9.setObjectName("label_9")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.frame)
        self.lineEdit_4.setGeometry(QtCore.QRect(110, 300, 291, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_4.setFont(font)
        self.lineEdit_4.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_4.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_4.setReadOnly(False)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.label_10 = QtWidgets.QLabel(self.frame)
        self.label_10.setGeometry(QtCore.QRect(40, 360, 51, 21))
        self.label_10.setStyleSheet("QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_10.setObjectName("label_10")
        self.lineEdit_5 = QtWidgets.QLineEdit(self.frame)
        self.lineEdit_5.setGeometry(QtCore.QRect(110, 360, 291, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_5.setFont(font)
        self.lineEdit_5.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_5.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_5.setReadOnly(False)
        self.lineEdit_5.setObjectName("lineEdit_5")
        self.label_11 = QtWidgets.QLabel(self.frame)
        self.label_11.setGeometry(QtCore.QRect(30, 460, 51, 21))
        self.label_11.setStyleSheet("QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_11.setObjectName("label_11")
        self.comboBox = QtWidgets.QComboBox(self.frame)
        self.comboBox.setGeometry(QtCore.QRect(90, 460, 101, 22))
        self.comboBox.setObjectName("comboBox")
        self.label_12 = QtWidgets.QLabel(self.frame)
        self.label_12.setGeometry(QtCore.QRect(210, 460, 91, 21))
        self.label_12.setStyleSheet("QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_12.setObjectName("label_12")
        self.comboBox_2 = QtWidgets.QComboBox(self.frame)
        self.comboBox_2.setGeometry(QtCore.QRect(320, 460, 101, 22))
        self.comboBox_2.setObjectName("comboBox_2")
        self.label_13 = QtWidgets.QLabel(self.frame)
        self.label_13.setGeometry(QtCore.QRect(40, 410, 81, 21))
        self.label_13.setStyleSheet("QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_13.setObjectName("label_13")
        self.lineEdit_6 = QtWidgets.QLineEdit(self.frame)
        self.lineEdit_6.setGeometry(QtCore.QRect(180, 410, 201, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_6.setFont(font)
        self.lineEdit_6.setStyleSheet("background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_6.setReadOnly(False)
        self.lineEdit_6.setObjectName("lineEdit_6")
        self.save_btn = QtWidgets.QPushButton(self.frame)
        self.save_btn.setGeometry(QtCore.QRect(200, 510, 101, 23))
        self.save_btn.setStyleSheet("QPushButton#save_btn{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #005c99, stop:1 #008ae6);\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#save_btn:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #1aa3ff, stop:1#1a1aff);\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#save_btn:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.save_btn.setObjectName("save_btn")
        self.back_btn = QtWidgets.QPushButton(self.frame)
        self.back_btn.setGeometry(QtCore.QRect(20, 10, 31, 23))
        self.back_btn.setStyleSheet("QPushButton#back_btn{\n"
"border:0;\n"
"\n"
"\n"
"}\n"
"\n"
"QPushButton#back_btn:hover{\n"
"background-color:white;\n"
"}")
        self.back_btn.setText("Save")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/newPrefix/back.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.back_btn.setIcon(icon)
        self.back_btn.setObjectName("back_btn")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Sign Up Here"))
        self.browse_bt.setText(_translate("MainWindow", "Browse"))
        self.label_6.setText(_translate("MainWindow", "Personal Details"))
        self.label_7.setText(_translate("MainWindow", "Name"))
        self.lineEdit_2.setPlaceholderText(_translate("MainWindow", "Enter Name"))
        self.label_8.setText(_translate("MainWindow", "Username"))
        self.lineEdit_3.setPlaceholderText(_translate("MainWindow", "username"))
        self.label_9.setText(_translate("MainWindow", "Password"))
        self.lineEdit_4.setPlaceholderText(_translate("MainWindow", "Password"))
        self.label_10.setText(_translate("MainWindow", "Confrim"))
        self.lineEdit_5.setPlaceholderText(_translate("MainWindow", "Password"))
        self.label_11.setText(_translate("MainWindow", "Standard"))
        self.label_12.setText(_translate("MainWindow", "Favorite Subject"))
        self.label_13.setText(_translate("MainWindow", "Password Hint"))
        self.lineEdit_6.setPlaceholderText(_translate("MainWindow", "Password Hint"))
        self.save_btn.setText(_translate("MainWindow", "Browse"))
    def setImg(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.file_path = filedialog.askopenfilename()
        self.label.setPixmap(QtGui.QPixmap(self.file_path))



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
