# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import icons_rc

class Ui_login_Window(object):
    def setupUi(self, login_Window):
        if not login_Window.objectName():
            login_Window.setObjectName(u"login_Window")
        login_Window.resize(592, 330)
        font = QFont()
        font.setPointSize(16)
        font.setBold(True)
        font.setWeight(75)
        login_Window.setFont(font)
        self.centralwidget = QWidget(login_Window)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(10, 10, 571, 301))
        self.frame.setStyleSheet(u"background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));\n"
"border-radius:5px;")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(170, 20, 191, 61))
        font1 = QFont()
        font1.setPointSize(32)
        font1.setBold(True)
        font1.setWeight(75)
        self.label.setFont(font1)
        self.label.setStyleSheet(u"background-color:none;\n"
"color:rgba(255,255,255,255);")
        self.label.setAlignment(Qt.AlignCenter)
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(40, 110, 71, 31))
        font2 = QFont()
        font2.setPointSize(12)
        self.label_2.setFont(font2)
        self.label_2.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.label_3 = QLabel(self.frame)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(40, 170, 71, 31))
        self.label_3.setFont(font2)
        self.label_3.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.lineEdit = QLineEdit(self.frame)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setGeometry(QRect(150, 120, 241, 31))
        self.lineEdit.setFont(font2)
        self.lineEdit.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :1px solid  rgba(255, 255, 255, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;\n"
"\n"
"border-radius:none;")
        self.PushButton = QPushButton(self.frame)
        self.PushButton.setObjectName(u"PushButton")
        self.PushButton.setGeometry(QRect(280, 230, 151, 51))
        self.PushButton.setFont(font)
        self.PushButton.setStyleSheet(u"QPushButton#PushButton{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(255, 133, 223, 255), stop:1 rgba(182, 130, 255, 255));\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#PushButton:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#PushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.lineEdit_2 = QLineEdit(self.frame)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setGeometry(QRect(150, 170, 241, 31))
        self.lineEdit_2.setFont(font2)
        self.lineEdit_2.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :1px solid  rgba(255, 255, 255, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;\n"
"\n"
"border-radius:none;")
        self.lineEdit_2.setEchoMode(QLineEdit.Password)
        self.back_btn = QPushButton(self.frame)
        self.back_btn.setObjectName(u"back_btn")
        self.back_btn.setGeometry(QRect(540, 10, 21, 23))
        font3 = QFont()
        font3.setPointSize(12)
        font3.setBold(True)
        font3.setWeight(75)
        self.back_btn.setFont(font3)
        self.back_btn.setStyleSheet(u"QPushButton#back_btn{\n"
"background:none;\n"
"	\n"
"}\n"
"\n"
"\n"
"QPushButton#back_btn:hover{\n"
"background-color:red;\n"
"color:white;\n"
"border:1px solid white;\n"
"border-radius:0px;\n"
"}\n"
"\n"
"QPushButton#PushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        login_Window.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(login_Window)
        self.statusbar.setObjectName(u"statusbar")
        login_Window.setStatusBar(self.statusbar)

        self.retranslateUi(login_Window)

        QMetaObject.connectSlotsByName(login_Window)
    # setupUi

    def retranslateUi(self, login_Window):
        login_Window.setWindowTitle(QCoreApplication.translate("login_Window", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("login_Window", u"Login", None))
        self.label_2.setText(QCoreApplication.translate("login_Window", u"Username", None))
        self.label_3.setText(QCoreApplication.translate("login_Window", u"Password", None))
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("login_Window", u"Username", None))
        self.PushButton.setText(QCoreApplication.translate("login_Window", u"Login", None))
        self.lineEdit_2.setPlaceholderText(QCoreApplication.translate("login_Window", u"Password", None))
        self.back_btn.setText(QCoreApplication.translate("login_Window", u"x", None))
    # retranslateUi

