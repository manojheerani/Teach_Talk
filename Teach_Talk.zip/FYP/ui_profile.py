# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'profile.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import icons_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(512, 585)
        Form.setStyleSheet(u"\n"
"background-color: qlineargradient(spread:pad, x1:0.295455, y1:0.159, x2:1, y2:1, stop:0.361295 rgba(18, 0, 37, 255), stop:0.854314 rgba(232, 36, 84, 255), stop:0.982955 rgba(255, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius:7px;\n"
"")
        self.frame = QFrame(Form)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, -10, 511, 171))
        self.frame.setStyleSheet(u"QFrame#frame{\n"
"background:white;\n"
"bordertop:none;\n"
"border-bottom:1px sloid ;\n"
"border-radius:10px;\n"
"}")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(200, 60, 101, 101))
        self.label.setStyleSheet(u"QLabel#label{\n"
"background:black;\n"
"border-radius:45px;\n"
"}")
        self.label.setPixmap(QPixmap(u":/newPrefix/Icon/icons8-test-account-96.png"))
        self.label.setScaledContents(True)
        self.frame_2 = QFrame(Form)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setGeometry(QRect(0, 160, 511, 431))
        self.frame_2.setStyleSheet(u"background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.pushButton = QPushButton(self.frame_2)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(210, 50, 75, 23))
        font = QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet(u"QPushButton#pushButton{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#pushButton:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.frame_3 = QFrame(self.frame_2)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setGeometry(QRect(0, 80, 511, 221))
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.label_2 = QLabel(self.frame_3)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(10, 10, 81, 16))
        self.label_2.setStyleSheet(u"QLabel#label_2{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.lineEdit = QLineEdit(self.frame_3)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setGeometry(QRect(20, 50, 201, 31))
        font1 = QFont()
        font1.setPointSize(10)
        self.lineEdit.setFont(font1)
        self.lineEdit.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.lineEdit.setReadOnly(True)
        self.lineEdit_3 = QLineEdit(self.frame_3)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setGeometry(QRect(270, 150, 201, 31))
        self.lineEdit_3.setFont(font1)
        self.lineEdit_3.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.lineEdit_3.setReadOnly(True)
        self.lineEdit_4 = QLineEdit(self.frame_3)
        self.lineEdit_4.setObjectName(u"lineEdit_4")
        self.lineEdit_4.setGeometry(QRect(270, 50, 201, 31))
        self.lineEdit_4.setFont(font1)
        self.lineEdit_4.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"")
        self.lineEdit_4.setReadOnly(True)
        self.edit = QPushButton(self.frame_3)
        self.edit.setObjectName(u"edit")
        self.edit.setGeometry(QRect(430, 0, 75, 23))
        self.edit.setFont(font)
        self.edit.setStyleSheet(u"QPushButton#edit{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#edit:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#edit:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.comboBox = QComboBox(self.frame_3)
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(100, 110, 121, 22))
        self.label_3 = QLabel(self.frame_3)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(20, 110, 51, 16))
        self.label_3.setStyleSheet(u"QLabel#label_3{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.lineEdit_5 = QLineEdit(self.frame_3)
        self.lineEdit_5.setObjectName(u"lineEdit_5")
        self.lineEdit_5.setGeometry(QRect(20, 150, 201, 31))
        self.lineEdit_5.setFont(font1)
        self.lineEdit_5.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.lineEdit_5.setReadOnly(True)
        self.Name = QLabel(self.frame_2)
        self.Name.setObjectName(u"Name")
        self.Name.setGeometry(QRect(100, 10, 301, 20))
        font2 = QFont()
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setWeight(75)
        self.Name.setFont(font2)
        self.Name.setStyleSheet(u"QLabel#Name{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.Name.setAlignment(Qt.AlignCenter)
        self.frame_4 = QFrame(self.frame_2)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setGeometry(QRect(0, 300, 511, 121))
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.label_4 = QLabel(self.frame_4)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(0, 0, 81, 16))
        self.label_4.setStyleSheet(u"QLabel#label_4{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.username = QLineEdit(self.frame_4)
        self.username.setObjectName(u"username")
        self.username.setGeometry(QRect(70, 30, 201, 31))
        self.username.setFont(font1)
        self.username.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.username.setReadOnly(True)
        self.password = QLineEdit(self.frame_4)
        self.password.setObjectName(u"password")
        self.password.setGeometry(QRect(70, 90, 201, 31))
        self.password.setFont(font1)
        self.password.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setReadOnly(True)
        self.username_2 = QLineEdit(self.frame_4)
        self.username_2.setObjectName(u"username_2")
        self.username_2.setGeometry(QRect(330, 90, 141, 31))
        self.username_2.setFont(font1)
        self.username_2.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
"color: rgba(255,255,255,230);\n"
"padding-bottom:7px;")
        self.username_2.setReadOnly(True)
        self.label_5 = QLabel(self.frame_4)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(320, 40, 151, 16))
        self.label_5.setStyleSheet(u"QLabel#label_5{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_5.setAlignment(Qt.AlignCenter)
        self.save = QPushButton(self.frame_4)
        self.save.setObjectName(u"save")
        self.save.setGeometry(QRect(424, 10, 81, 23))
        self.save.setFont(font)
        self.save.setStyleSheet(u"QPushButton#save{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#save:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#save:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label.setText("")
        self.pushButton.setText(QCoreApplication.translate("Form", u"Change", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"Personal Details", None))
        self.edit.setText(QCoreApplication.translate("Form", u"Edit", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"Standard", None))
        self.Name.setText(QCoreApplication.translate("Form", u"Personal Details", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"Personal Details", None))
        self.username.setPlaceholderText(QCoreApplication.translate("Form", u"username", None))
        self.password.setPlaceholderText(QCoreApplication.translate("Form", u"Password", None))
        self.username_2.setPlaceholderText(QCoreApplication.translate("Form", u"username", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"Password hint", None))
        self.save.setText(QCoreApplication.translate("Form", u"Save", None))
    # retranslateUi

