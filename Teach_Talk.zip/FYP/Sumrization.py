import pandas as pd

import numpy as np

from transformers import pipeline
from bs4 import BeautifulSoup
import requests
summarizer = pipeline('summarization')
url = "https://www.britannica.com/science/physics-science"
r = requests.get(url)
soup = BeautifulSoup(r.text,('html.parser'))
results = soup.find_all(['h1','p'])
text = [result.text for result in results]
article = ' '.join(text)

article = article.replace('.','.<eso>')
article = article.replace('!','!<eso>')
article = article.replace('?','?<eso>')
sentences = article.split('<eso>')

sentences[0]

max_chunk = 500
current_chunk = 0
chunk = []
for sentence in sentences:
    if len(chunk)==current_chunk+1:
        if len(chunk[current_chunk])+len(sentence.split(' '))<= max_chunk:
            chunk[current_chunk].extend(sentence.split(' '))
        else:
            current_chunk+=1
            chunk.append(sentence.split(' '))
    else:
        print(current_chunk)
        chunk.append(sentence.split(' '))
        
for chunk_id in range(len(chunk)):
       chunk[chunk_id] = ' '.join(chunk[chunk_id])
       
len(chunk[0].split(' '))

res = summarizer(chunk,max_length=100,min_length=30,do_sample=False)
len(res)
' '.join([sum['summary_text'] for sum in res])



res[0]['summary_text']