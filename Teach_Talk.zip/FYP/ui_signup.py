# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'signup.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import icons_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(533, 577)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 531, 571))
        self.frame.setStyleSheet(u"background-color: #4da6ff;")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(180, 10, 291, 61))
        font = QFont()
        font.setPointSize(30)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"QLabel#label{\n"
"color: white;\n"
"}\n"
"QLabel#labe:hoverl{\n"
"color: red;\n"
"}")
        self.label.setAlignment(Qt.AlignCenter)
        self.img_lbl = QLabel(self.frame)
        self.img_lbl.setObjectName(u"img_lbl")
        self.img_lbl.setGeometry(QRect(20, 40, 101, 111))
        self.img_lbl.setStyleSheet(u"background-color:grey;")
        self.img_lbl.setScaledContents(True)
        self.browse_bt = QPushButton(self.frame)
        self.browse_bt.setObjectName(u"browse_bt")
        self.browse_bt.setGeometry(QRect(20, 160, 101, 23))
        self.browse_bt.setStyleSheet(u"QPushButton#browse_bt{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #005c99, stop:1 #008ae6);\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#browse_bt:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #1aa3ff, stop:1#1a1aff);\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#browse_bt:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.label_6 = QLabel(self.frame)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(140, 140, 81, 16))
        self.label_6.setStyleSheet(u"QLabel#label_6{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.label_7 = QLabel(self.frame)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(50, 190, 41, 21))
        self.label_7.setStyleSheet(u"QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.lineEdit_2 = QLineEdit(self.frame)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setGeometry(QRect(110, 190, 291, 31))
        font1 = QFont()
        font1.setPointSize(10)
        self.lineEdit_2.setFont(font1)
        self.lineEdit_2.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_2.setReadOnly(False)
        self.label_8 = QLabel(self.frame)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(40, 240, 51, 21))
        self.label_8.setStyleSheet(u"QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.lineEdit_3 = QLineEdit(self.frame)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setGeometry(QRect(110, 240, 291, 31))
        self.lineEdit_3.setFont(font1)
        self.lineEdit_3.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_3.setReadOnly(False)
        self.label_9 = QLabel(self.frame)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(40, 300, 51, 21))
        self.label_9.setStyleSheet(u"QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.lineEdit_4 = QLineEdit(self.frame)
        self.lineEdit_4.setObjectName(u"lineEdit_4")
        self.lineEdit_4.setGeometry(QRect(110, 300, 291, 31))
        self.lineEdit_4.setFont(font1)
        self.lineEdit_4.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_4.setEchoMode(QLineEdit.Password)
        self.lineEdit_4.setReadOnly(False)
        self.label_10 = QLabel(self.frame)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(40, 360, 51, 21))
        self.label_10.setStyleSheet(u"QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.lineEdit_5 = QLineEdit(self.frame)
        self.lineEdit_5.setObjectName(u"lineEdit_5")
        self.lineEdit_5.setGeometry(QRect(110, 360, 291, 31))
        self.lineEdit_5.setFont(font1)
        self.lineEdit_5.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_5.setEchoMode(QLineEdit.Password)
        self.lineEdit_5.setReadOnly(False)
        self.label_11 = QLabel(self.frame)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(30, 460, 51, 21))
        self.label_11.setStyleSheet(u"QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.comboBox = QComboBox(self.frame)
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(90, 460, 101, 22))
        self.label_12 = QLabel(self.frame)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setGeometry(QRect(210, 460, 91, 21))
        self.label_12.setStyleSheet(u"QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.comboBox_2 = QComboBox(self.frame)
        self.comboBox_2.setObjectName(u"comboBox_2")
        self.comboBox_2.setGeometry(QRect(320, 460, 101, 22))
        self.label_13 = QLabel(self.frame)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(40, 410, 81, 21))
        self.label_13.setStyleSheet(u"QLabel{\n"
"background:none;\n"
"color: white;\n"
"}")
        self.lineEdit_6 = QLineEdit(self.frame)
        self.lineEdit_6.setObjectName(u"lineEdit_6")
        self.lineEdit_6.setGeometry(QRect(180, 410, 201, 31))
        self.lineEdit_6.setFont(font1)
        self.lineEdit_6.setStyleSheet(u"background-color:rgba(0,0,0,0);\n"
"border:none;\n"
"\n"
"border-bottom :2px solid #b3d1ff;\n"
"color: white;\n"
"padding-bottom:7px;")
        self.lineEdit_6.setReadOnly(False)
        self.save_btn = QPushButton(self.frame)
        self.save_btn.setObjectName(u"save_btn")
        self.save_btn.setGeometry(QRect(200, 510, 101, 31))
        self.save_btn.setStyleSheet(u"QPushButton#save_btn{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #005c99, stop:1 #008ae6);\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#save_btn:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 #1aa3ff, stop:1#1a1aff);\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#save_btn:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}")
        self.back_btn = QPushButton(self.frame)
        self.back_btn.setObjectName(u"back_btn")
        self.back_btn.setGeometry(QRect(20, 10, 31, 23))
        self.back_btn.setStyleSheet(u"QPushButton#back_btn{\n"
"border:0;\n"
"\n"
"\n"
"}\n"
"\n"
"QPushButton#back_btn:hover{\n"
"background-color:white;\n"
"}")
        icon = QIcon()
        icon.addFile(u":/newPrefix/back.png", QSize(), QIcon.Normal, QIcon.Off)
        self.back_btn.setIcon(icon)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Sign Up Here", None))
        self.img_lbl.setText("")
        self.browse_bt.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"Personal Details", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"Name", None))
        self.lineEdit_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Name", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Username", None))
        self.lineEdit_3.setPlaceholderText(QCoreApplication.translate("MainWindow", u"username", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Password", None))
        self.lineEdit_4.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Password", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Confrim", None))
        self.lineEdit_5.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Password", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"Standard", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Favorite Subject", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"Password Hint", None))
        self.lineEdit_6.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Password Hint", None))
        self.save_btn.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.back_btn.setText("")
    # retranslateUi

