from googletrans import Translator
from gtts import gTTS
from playsound import playsound
import pyttsx3

translator = Translator()


try:
    translated = translator.translate('My name is izhar', src='en', dest='ur')

    print(translated.text)

    # voice = gTTS(translated.text,lang='ur')
    # voice.save('voice.mp3')
    # playsound('voice.mp3')
    a = translated.text
    engine = pyttsx3.init('sapi5')
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)
    engine.say("My name is Izhar")
    engine.runAndWait()
except Exception as e:
    print(e)