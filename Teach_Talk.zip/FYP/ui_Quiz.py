# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Quiz.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(662, 478)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(10, 0, 641, 451))
        self.frame.setStyleSheet(u"background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));\n"
"border-radius:7px;")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(220, 10, 181, 51))
        font = QFont()
        font.setPointSize(32)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.label.setAlignment(Qt.AlignCenter)
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(20, 120, 31, 31))
        font1 = QFont()
        font1.setPointSize(14)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_2.setFont(font1)
        self.label_2.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.label_3 = QLabel(self.frame)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(70, 120, 541, 31))
        font2 = QFont()
        font2.setPointSize(14)
        font2.setBold(False)
        font2.setWeight(50)
        self.label_3.setFont(font2)
        self.label_3.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.radioButton = QRadioButton(self.frame)
        self.radioButton.setObjectName(u"radioButton")
        self.radioButton.setGeometry(QRect(50, 210, 41, 21))
        font3 = QFont()
        font3.setPointSize(12)
        font3.setBold(True)
        font3.setWeight(75)
        self.radioButton.setFont(font3)
        self.radioButton.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.radioButton_2 = QRadioButton(self.frame)
        self.radioButton_2.setObjectName(u"radioButton_2")
        self.radioButton_2.setGeometry(QRect(50, 260, 41, 21))
        self.radioButton_2.setFont(font3)
        self.radioButton_2.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.radioButton_3 = QRadioButton(self.frame)
        self.radioButton_3.setObjectName(u"radioButton_3")
        self.radioButton_3.setGeometry(QRect(50, 310, 41, 21))
        self.radioButton_3.setFont(font3)
        self.radioButton_3.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.radioButton_4 = QRadioButton(self.frame)
        self.radioButton_4.setObjectName(u"radioButton_4")
        self.radioButton_4.setGeometry(QRect(50, 360, 41, 21))
        self.radioButton_4.setFont(font3)
        self.radioButton_4.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.label_4 = QLabel(self.frame)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(110, 210, 511, 31))
        font4 = QFont()
        font4.setPointSize(12)
        font4.setBold(False)
        font4.setWeight(50)
        self.label_4.setFont(font4)
        self.label_4.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.label_5 = QLabel(self.frame)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(110, 260, 511, 31))
        self.label_5.setFont(font4)
        self.label_5.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.label_6 = QLabel(self.frame)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(110, 310, 511, 31))
        self.label_6.setFont(font4)
        self.label_6.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.label_7 = QLabel(self.frame)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(110, 360, 511, 31))
        self.label_7.setFont(font4)
        self.label_7.setStyleSheet(u"background-color:none;\n"
"color:white;")
        self.PushButton = QPushButton(self.frame)
        self.PushButton.setObjectName(u"PushButton")
        self.PushButton.setGeometry(QRect(250, 400, 141, 41))
        font5 = QFont()
        font5.setPointSize(18)
        font5.setBold(True)
        font5.setWeight(75)
        self.PushButton.setFont(font5)
        self.PushButton.setStyleSheet(u"QPushButton{\n"
"background-color: qlineargradient(spread:reflect, x1:0.0339096, y1:0.022, x2:1, y2:1, stop:0 rgba(180, 119, 205, 255), stop:0.932203 rgba(207, 150, 114, 255));\n"
"color:white;\n"
"}\n"
"QPushButton:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Quiz", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Q:", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"The symbol used for potassium element is ____ ", None))
        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"a", None))
        self.radioButton_2.setText(QCoreApplication.translate("MainWindow", u"b", None))
        self.radioButton_3.setText(QCoreApplication.translate("MainWindow", u"c", None))
        self.radioButton_4.setText(QCoreApplication.translate("MainWindow", u"d", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"P", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"K", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"Pt", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"Na", None))
        self.PushButton.setText(QCoreApplication.translate("MainWindow", u"Next", None))
    # retranslateUi

