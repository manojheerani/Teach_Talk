

# from itertools import count
# from shutil import move
from PyQt5 import QtCore, QtGui, QtWidgets

from PyQt5.QtGui import QMovie
from PyQt5.QtCore import QTimer
count = 0
class Loading(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(178, 157)
        MainWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        MainWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        MainWindow.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        MainWindow.setStyleSheet("background:none;")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.movie = QMovie('MnyxU.gif')
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, 10, 161, 111))
        self.label.setStyleSheet("background:none;")
        self.label.setText("")
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.label.setMovie(self.movie)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.Timerr)
        self.timer.start(35)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
    
        
        
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
    def start_anim(self):
        self.movie.start()
    def stop_anim(self):
        self.movie.stop()
        MainWindow.close()
    def Timerr(self):
        self.start_anim()
        global count
        if count>50:
            self.timer.stop()
            self.stop_anim()
        count +=1;


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Loading()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
