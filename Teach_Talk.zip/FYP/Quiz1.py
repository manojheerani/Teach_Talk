

from symbol import lambdef
from PyQt5 import QtCore, QtGui, QtWidgets


class Quiz(object):
    def setupUi(self, MainWindow):
        self.q_List = ['The symbol used for potassium element is ____ ','Which of the following has strongest intermolecular forces of attraction?']
        self.op_list = ['P','K','Pt','Na','Hydrogen (H2)','Chlorine (Cl2)',' iodine (I2)','Methane (CH4)']
        
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(662, 478)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(10, 0, 641, 451))
        self.frame.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));\n"
"border-radius:7px;")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(220, 10, 181, 51))
        font = QtGui.QFont()
        font.setPointSize(32)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(20, 120, 31, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.frame)
        self.label_3.setGeometry(QtCore.QRect(70, 120, 541, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(False)
        font.setWeight(50)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_3.setObjectName("label_3")
        self.radioButton = QtWidgets.QRadioButton(self.frame)
        self.radioButton.setGeometry(QtCore.QRect(50, 210, 41, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.radioButton.setFont(font)
        self.radioButton.setStyleSheet("background-color:none;\n"
"color:white;")
        self.radioButton.setObjectName("radioButton")
        self.radioButton_2 = QtWidgets.QRadioButton(self.frame)
        self.radioButton_2.setGeometry(QtCore.QRect(50, 260, 41, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.radioButton_2.setFont(font)
        self.radioButton_2.setStyleSheet("background-color:none;\n"
"color:white;")
        self.radioButton_2.setObjectName("radioButton_2")
        self.radioButton_3 = QtWidgets.QRadioButton(self.frame)
        self.radioButton_3.setGeometry(QtCore.QRect(50, 310, 41, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.radioButton_3.setFont(font)
        self.radioButton_3.setStyleSheet("background-color:none;\n"
"color:white;")
        self.radioButton_3.setObjectName("radioButton_3")
        self.radioButton_4 = QtWidgets.QRadioButton(self.frame)
        self.radioButton_4.setGeometry(QtCore.QRect(50, 360, 41, 21))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.radioButton_4.setFont(font)
        self.radioButton_4.setStyleSheet("background-color:none;\n"
"color:white;")
        self.radioButton_4.setObjectName("radioButton_4")
        self.label_4 = QtWidgets.QLabel(self.frame)
        self.label_4.setGeometry(QtCore.QRect(110, 210, 511, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.frame)
        self.label_5.setGeometry(QtCore.QRect(110, 260, 511, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.frame)
        self.label_6.setGeometry(QtCore.QRect(110, 310, 511, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.label_6.setFont(font)
        self.label_6.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.frame)
        self.label_7.setGeometry(QtCore.QRect(110, 360, 511, 31))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.label_7.setFont(font)
        self.label_7.setStyleSheet("background-color:none;\n"
"color:white;")
        self.label_7.setObjectName("label_7")
        self.PushButton = QtWidgets.QPushButton(self.frame,clicked=lambda:self.set_Q)
        self.PushButton.setGeometry(QtCore.QRect(250, 400, 141, 41))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton.setFont(font)
        self.PushButton.setStyleSheet("QPushButton{\n"
"background-color: qlineargradient(spread:reflect, x1:0.0339096, y1:0.022, x2:1, y2:1, stop:0 rgba(180, 119, 205, 255), stop:0.932203 rgba(207, 150, 114, 255));\n"
"color:white;\n"
"}\n"
"QPushButton:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"QPushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"")
        self.PushButton.setObjectName("PushButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Quiz"))
        self.label_2.setText(_translate("MainWindow", "Q:"))
        self.label_3.setText(_translate("MainWindow", "The symbol used for potassium element is ____ "))
        self.radioButton.setText(_translate("MainWindow", "a"))
        self.radioButton_2.setText(_translate("MainWindow", "b"))
        self.radioButton_3.setText(_translate("MainWindow", "c"))
        self.radioButton_4.setText(_translate("MainWindow", "d"))
        self.label_4.setText(_translate("MainWindow", "P"))
        self.label_5.setText(_translate("MainWindow", "K"))
        self.label_6.setText(_translate("MainWindow", "Pt"))
        self.label_7.setText(_translate("MainWindow", "Na"))
        self.PushButton.setText(_translate("MainWindow", "Next"))
    
    def set_Q(self):
        ss = 1
        while ss<3:
                
                if ss == 1:
                        
                        self.label_2.setText('Q 1')
                        self.label_3.setText(self.q_List[0])
                        self.label_4.setText(self.op_list[0])
                        self.label_5.setText(self.op_list[1])
                        self.label_6.setText(self.op_list[2])
                        self.label_7.setText(self.op_list[3])
                elif ss == 2:
                        self.label_2.setText('Q 2')
                        self.label_3.setText(self.q_List[1])
                        self.label_4.setText(self.op_list[4])
                        self.label_5.setText(self.op_list[5])
                        self.label_6.setText(self.op_list[6])
                        self.label_7.setText(self.op_list[7])
                ss +=1


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
