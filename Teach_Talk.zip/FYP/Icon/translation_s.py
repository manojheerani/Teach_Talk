from tkinter import StringVar, messagebox
from googletrans import Translator


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(673, 385)
        MainWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        MainWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        MainWindow.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(10, 10, 651, 341))
        self.frame.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0.028, y1:0.0334545, x2:1, y2:1, stop:0 rgba(194, 64, 180, 255), stop:1 rgba(255, 187, 187, 255));\n"
"border-radius:7px;")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.frame)
        self.plainTextEdit.setGeometry(QtCore.QRect(10, 40, 631, 121))
        self.plainTextEdit.setStyleSheet("QPlainTextEdit#plainTextEdit{\n"
"background:white;\n"
"color:black;\n"
"border-radius:3px\n"
"}")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.plainTextEdit_2 = QtWidgets.QPlainTextEdit(self.frame)
        self.plainTextEdit_2.setGeometry(QtCore.QRect(10, 170, 631, 131))
        self.plainTextEdit_2.setStyleSheet("QPlainTextEdit#plainTextEdit_2{\n"
"background:white;\n"
"color:black;\n"
"border-radius:3px\n"
"}")
        self.plainTextEdit_2.setReadOnly(True)
        self.plainTextEdit_2.setObjectName("plainTextEdit_2")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(20, 10, 91, 16))
        self.label.setStyleSheet("QLabel#label{\n"
"background:none;\n"
"color:white;\n"
"}")
        self.label.setObjectName("label")
        var =''
        self.comboBox = QtWidgets.QComboBox(self.frame )
        self.comboBox.setGeometry(QtCore.QRect(458, 10, 181, 22))
        self.comboBox.setObjectName("comboBox")
        self.lang_list = ['','English', 'Urdu', 'Sindhi']
        self.comboBox.addItems(self.lang_list)
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(350, 10, 91, 16))
        self.label_2.setStyleSheet("QLabel#label_2{\n"
"background:none;\n"
"color:white;\n"
"}")
        self.label_2.setObjectName("label_2")
        self.pushButton = QtWidgets.QPushButton(self.frame , clicked=lambda: self._translator())
        self.pushButton.setGeometry(QtCore.QRect(234, 310, 161, 23))
        self.pushButton.setStyleSheet("QPushButton#pushButton{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
"color:rgba(255,255,255,1);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"\n"
"QPushButton#pushButton:hover{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton:pressed{\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
"color:rgba(255,255,255,210);\n"
"border-radius:5px;\n"
"}\n"
"\n"
"")
        self.pushButton.setObjectName("pushButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Original Text"))
        self.label_2.setText(_translate("MainWindow", "Select Language"))
        self.pushButton.setText(_translate("MainWindow", "Translate"))
    def _translator(self):
        translator = Translator()
        # org_txt = self.plainTextEdit.te
        try:
                org_text = self.plainTextEdit.toPlainText()
             
                self.currentLang = ''
                if(self.comboBox.currentText() == 'Sindhi'):
                        self.currentLang = 'sd'
                elif (self.comboBox.currentText() == 'Urdu'):
                        self.currentLang = 'ur'
                translated_text = translator.translate(text= org_text,  src = 'en',dest = self.currentLang)
        
                self.plainTextEdit_2.setPlainText(translated_text.text)
        except:
                messagebox.showerror('Please Select any language')
       
        

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
