from distutils.cmd import Command
import icons
import speech_recognition as sr
import pyttsx3

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_TeachTalk(object):
        
        
        
        
        
    def setupUi(self, TeachTalk):
        TeachTalk.setObjectName("TeachTalk")
        TeachTalk.resize(1350, 671)
        TeachTalk.setStyleSheet("")
        self.centralwidget = QtWidgets.QWidget(TeachTalk)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(0, 0, 171, 680))
        self.frame.setStyleSheet("QFrame#frame{\n"
                                 "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(181, 86, 249, 255), stop:1 rgba(182, 130, 255, 255));\n"
                                 "}\n"
                                 "")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.PushButton = QtWidgets.QPushButton(self.frame)
        self.PushButton.setGeometry(QtCore.QRect(10, 40, 146, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton.setFont(font)
        self.PushButton.setStyleSheet("QPushButton#PushButton{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                      "color:rgba(255,255,255,1);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "\n"
                                      "QPushButton#PushButton:hover{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "QPushButton#PushButton:pressed{\n"
                                      "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                      "color:rgba(255,255,255,210);\n"
                                      "border-radius:5px;\n"
                                      "}\n"
                                      "\n"
                                      "")
        self.PushButton.setObjectName("PushButton")
        self.PushButton_2 = QtWidgets.QPushButton(self.frame)
        self.PushButton_2.setGeometry(QtCore.QRect(10, 110, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton_2.setFont(font)
        self.PushButton_2.setStyleSheet("QPushButton#PushButton_2{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                        "color:rgba(255,255,255,1);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "\n"
                                        "QPushButton#PushButton_2:hover{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton#PushButton_2:pressed{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "")
        self.PushButton_2.setObjectName("PushButton_2")
        self.PushButton_3 = QtWidgets.QPushButton(self.frame)
        self.PushButton_3.setGeometry(QtCore.QRect(10, 180, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton_3.setFont(font)
        self.PushButton_3.setStyleSheet("QPushButton#PushButton_3{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                        "color:rgba(255,255,255,1);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "\n"
                                        "QPushButton#PushButton_3:hover{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton#PushButton_3:pressed{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "")
        self.PushButton_3.setObjectName("PushButton_3")
        self.PushButton_4 = QtWidgets.QPushButton(self.frame)
        self.PushButton_4.setGeometry(QtCore.QRect(10, 250, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton_4.setFont(font)
        self.PushButton_4.setStyleSheet("QPushButton#PushButton_4{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                        "color:rgba(255,255,255,1);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "\n"
                                        "QPushButton#PushButton_4:hover{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton#PushButton_4:pressed{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "")
        self.PushButton_4.setObjectName("PushButton_4")
        self.PushButton_5 = QtWidgets.QPushButton(self.frame)
        self.PushButton_5.setGeometry(QtCore.QRect(10, 310, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton_5.setFont(font)
        self.PushButton_5.setStyleSheet("QPushButton#PushButton_5{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                        "color:rgba(255,255,255,1);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "\n"
                                        "QPushButton#PushButton_5:hover{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton#PushButton_5:pressed{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "")
        self.PushButton_5.setObjectName("PushButton_5")
        self.PushButton_6 = QtWidgets.QPushButton(self.frame)
        self.PushButton_6.setGeometry(QtCore.QRect(10, 380, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton_6.setFont(font)
        self.PushButton_6.setStyleSheet("QPushButton#PushButton_6{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                        "color:rgba(255,255,255,1);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "\n"
                                        "QPushButton#PushButton_6:hover{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton#PushButton_6:pressed{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "")
        self.PushButton_6.setObjectName("PushButton_6")
        self.PushButton_7 = QtWidgets.QPushButton(self.frame)
        self.PushButton_7.setGeometry(QtCore.QRect(10, 450, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton_7.setFont(font)
        self.PushButton_7.setStyleSheet("QPushButton#PushButton_7{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                        "color:rgba(255,255,255,1);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "\n"
                                        "QPushButton#PushButton_7:hover{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton#PushButton_7:pressed{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "")
        self.PushButton_7.setObjectName("PushButton_7")
        self.PushButton_8 = QtWidgets.QPushButton(self.frame)
        self.PushButton_8.setGeometry(QtCore.QRect(10, 520, 151, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.PushButton_8.setFont(font)
        self.PushButton_8.setStyleSheet("QPushButton#PushButton_8{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                        "color:rgba(255,255,255,1);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "\n"
                                        "QPushButton#PushButton_8:hover{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton#PushButton_8:pressed{\n"
                                        "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                        "color:rgba(255,255,255,210);\n"
                                        "border-radius:5px;\n"
                                        "}\n"
                                        "\n"
                                        "")
        self.PushButton_8.setObjectName("PushButton_8")
        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setGeometry(QtCore.QRect(169, -1, 1180, 680))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.frame_2.setFont(font)
        self.frame_2.setStyleSheet("QFrame#frame_2{\n"
                                   "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(181, 86, 249, 255), stop:1 rgba(182, 130, 255, 255));\n"
                                   "}\n"
                                   "")
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.lineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.lineEdit.setGeometry(QtCore.QRect(120, 40, 871, 31))
        # self.plainTextEdit.appendHtml('ssss')
        
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lineEdit.setFont(font)
        self.lineEdit.setStyleSheet("background-color:rgba(0,0,0,0);\n"
                                    "border:none;\n"
                                    "\n"
                                    "border-bottom :2px solid  rgba(137, 54, 246, 255);\n"
                                    "color: rgba(255,255,255,230);\n"
                                    "padding-bottom:7px;")
        self.lineEdit.setObjectName("lineEdit")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.frame_2)
        self.plainTextEdit.setGeometry(QtCore.QRect(10, 100, 1141, 511))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.plainTextEdit.setFont(font)
        self.plainTextEdit.setMouseTracking(True)
        self.plainTextEdit.setStyleSheet(
            "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(227, 160, 247, 240), stop:1 rgba(220, 217, 221, 255));")
        self.plainTextEdit.setReadOnly(True)
        self.plainTextEdit.setOverwriteMode(False)
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.plainTextEdit.appendPlainText('dsffdsfdsfsdfsdf')
        self.search = QtWidgets.QPushButton(self.frame_2)
        self.search.setGeometry(QtCore.QRect(990, 40, 21, 31))
        self.search.setStyleSheet("border-radius:40px;")
        self.search.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(
            ":/newPrefix/icons8-search-60.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.search.setIcon(icon)
        self.search.setIconSize(QtCore.QSize(18, 18))
        self.search.setObjectName("search")
        
        # self.obj =MethodsImplimentaion()
        
        
   
        
        
        self.voice_srch = QtWidgets.QPushButton(self.frame_2 , clicked= lambda: self.Voice_Search())
        self.voice_srch.setGeometry(QtCore.QRect(1010, 40, 21, 31))
        self.voice_srch.setStyleSheet("border-radius:40px;")
        self.voice_srch.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/newPrefix/google-voice.png"),
                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.voice_srch.setIcon(icon1)
        self.voice_srch.setIconSize(QtCore.QSize(20, 20))
        self.voice_srch.setObjectName("voice_srch")
        self.comboBox = QtWidgets.QComboBox(self.frame_2)
        self.comboBox.setGeometry(QtCore.QRect(1080, 50, 81, 22))
        self.lang_list = ['English', 'Urdu', 'Sindhi']
        self.comboBox.addItems(self.lang_list)
        # val = self.comboBox.itemData(self.comboBox.currentIndex())
        # print(val)
        self.comboBox.setStyleSheet("QComboBox#comboBox{\n"
                                    "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(210,119,252, 1), stop:1 rgba(161,1,110,1));\n"
                                    "color:rgba(255,255,255,1);\n"
                                    "border-radius:5px;\n"
                                    "}\n"
                                    "\n"
                                    "\n"
                                    "QComboBox#comboBox:hover{\n"
                                    "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(45,107,240, 219), stop:1 rgba(243, 95, 251, 255));\n"
                                    "color:rgba(255,255,255,210);\n"
                                    "border-radius:5px;\n"
                                    "}\n"
                                    "\n"
                                    "QComboBox#comboBox:pressed{\n"
                                    "background-color: qlineargradient(spread:pad, x1:0, y1:0.563, x2:1, y2:0.54, stop:0 rgba(20,47,78, 219), stop:1 rgba(85, 98, 12, 226));\n"
                                    "color:rgba(255,255,255,210);\n"
                                    "border-radius:5px;\n"
                                    "}")
        self.comboBox.setObjectName("comboBox")
        self.label = QtWidgets.QLabel(self.frame_2)
        self.label.setGeometry(QtCore.QRect(1080, 30, 81, 16))
        self.label.setObjectName("label")
        TeachTalk.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(TeachTalk)
        self.statusbar.setObjectName("statusbar")
        TeachTalk.setStatusBar(self.statusbar)

        self.retranslateUi(TeachTalk)
        QtCore.QMetaObject.connectSlotsByName(TeachTalk)

    def retranslateUi(self, TeachTalk):
        _translate = QtCore.QCoreApplication.translate
        TeachTalk.setWindowTitle(_translate("TeachTalk", "TeachTalk"))
        self.PushButton.setText(_translate("TeachTalk", "Login/SignUp"))
        self.PushButton_2.setText(_translate("TeachTalk", "Quiz"))
        self.PushButton_3.setText(_translate("TeachTalk", "Games"))
        self.PushButton_4.setText(_translate("TeachTalk", "Social"))
        self.PushButton_5.setText(_translate("TeachTalk", "Profile"))
        self.PushButton_6.setText(_translate("TeachTalk", "Books"))
        self.PushButton_7.setText(_translate("TeachTalk", "New Researchs"))
        self.PushButton_8.setText(_translate("TeachTalk", "Log Out"))
        self.lineEdit.setPlaceholderText(
            _translate("TeachTalk", "Search here"))
        self.label.setText(_translate("TeachTalk", "Select Language"))
        
    def Voice_Search(self):                            
                r = sr.Recognizer()
                mic = sr.Microphone()
                with mic as sourse:
                        self.lineEdit.setText('Listening....')
                        r.adjust_for_ambient_noise(sourse)
                        audio1 = r.listen(sourse)
                        a = r.recognize_google(audio1)
                        print(a)
                        self.lineEdit.setText(a)



class MethodsImplimentaion(Ui_TeachTalk):   
            
        def Voice_Search(self): 
               
                r = sr.Recognizer()
                mic = sr.Microphone()
                with mic as sourse:
                        self.lineEdit.text='Listening.....'
                        r.adjust_for_ambient_noise(sourse)
                        audio1 = r.listen(sourse)
                        a = r.recognize_google(audio1)
                        print(a)
                        self.lineEdit.text=a
                        
                        
                        # engine = pyttsx3.init('sapi5')
                        # voices = engine.getProperty('voices')
                        # engine.setProperty('voice', voices[0].id)
                        # engine.say(a)
                        # engine.runAndWait()
                        
             

        def Translation(text):
            pass

        def Loading():
            pass

        def get_Data(query):
            pass


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    TeachTalk = QtWidgets.QMainWindow()
    ui = Ui_TeachTalk()
    ui.setupUi(TeachTalk)
    TeachTalk.show()
    sys.exit(app.exec_())
