# open('C:\Users\Dell\Downloads\Documents\Physics 9.pdf','w')
path = 'Physics9.pdf'
import os
os.system(path)
